<?php 
 session_start();
	 if(!isset($_SESSION['user_master_name']) && !isset($SESSION['password']))
	 {
	     header("location:login.php");
	  }	 

include_once('unique.php');
include_once('header.php');


	if(isset($_POST['add_unique']))
		{

			$user_master_id=$_SESSION['user_master_id'];		
			$user_master_name=$_POST['user_master_name'];
		    	$email_id=$_POST['email_id'];
	$contact_no=$_POST['contact_no'];				
			$password=$_POST['password'];
			
		
		
			$update_profile="UPDATE user_master set user_master_name='$user_master_name' ,email_id='$email_id',contact_no=$contact_no  where user_master_id=$user_master_id";
			
				if(mysqli_query($coon,$update_profile))
				{
					echo("<script>alert('Sucsessfully Save..!!');</script>");
				}	
				else
				{
					echo("<script>alert('Error..!!');</script>");
				}
				
			
			
		}	
		

?>

			
				
<section class="header_text sub">
<section  class="homepage-slider" id="home-slider">
			
				
</section>				
			<img class="pageBanner" src="themes/images/pageBanner.png" alt="New products" >
			<div class="control-group"  style="margin-left: 145px! important;">
			<h4><span><b><center>My Profile</center></b></span></h4>		
				
</section>
		
<div class="box-body">
<table class="table table-striped">
								
								  <thead>
								  <tr>
									   <th><b>Sr No.</b></th>
									   <th><b>Name</b></th>
									   <th><b>Email Id </b></th>
									 
									   <th><b>Contact No</b></th>
							
								  </tr>
								  </thead> 
								  
							<?php
				  			$user_master_name=$_SESSION['user_master_name'];
                            $query="select * from user_master where user_master_name='$user_master_name'";
                            $result=mysqli_query($con,$query);
                            $row=mysqli_num_rows($result);
        
                            if($row>0)
                            {
							    $i = 1;
                                while($row=mysqli_fetch_assoc($result))
                                {                    
 		                       ?>	
					<tr>
					    <td ><?php echo($i); ?></td>
						<td><?php echo $row['user_master_name']; ?></td>
						
						<td><?php echo $row['email_id']; ?></td>
						<td><?php echo $row['contact_no']?></td>
					</tr>
					<?php
					$i++; 
				}
		}           
    ?>
	  
								  

				
		</table>	
		</div>
			<?php include_once('footer.php');?>