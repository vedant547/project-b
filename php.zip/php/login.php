<?php
inclue_once('connection.php');
if (isset($_POST['add_user_master']))
{
	$user_master_name=$_POST['name'];
	$password=$_POST['password'];
	$contact_no=$_POST['contact'];
	$email_id=$_POST['email_id'];
	$query="insert into user_master(user_master_name,password,contact_no,email_id)values('$user_master_name','$password',$contact_no,'$email_id')";
	if(mysqli_query($con,$query))
	{
		echo("<script>alert('Success')</script>");
	}
	else
	{
		echo("<script>alert('Error')</script>");
	}
}
?>
<form method="post">
Enter Name:<input type="input" name= "name"> <br>
Enter Address:<input type="input" name= "password"> <br>
Enter Contact:<input type="input" name= "contact"> <br>
Enter Contact:<input type="input" name= "email_id"> <br>
<input type="submit" Value="Submit" name="add_user_master">
</form>