connection.php
     $test="Unique furniture mart";
	 $conn=mysqli_connect("localhost","username","password","DBName");
	 if(!$conn)
	 {
	   die("error:",mysqli_connect_error);
	 }