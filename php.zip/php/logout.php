<?php include_once('header.php');
include_once('unique.php');

session_start();
	 if(!isset($_GET['action']))
       ($_SESSION['user_master_name']);	 
	     header("location:index.php"); 
?>
