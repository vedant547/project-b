<?php include_once('header.php');?>
<section class="header_text sub">
			<div class="control-group"  style="margin-left: 145px! important;">
					
				
</section>
                <center>
				<h4><span>BEDS</span></h4>
				</center>
			</section>
			<section class="main-content" style="margin-left: 145px! important;">
				
				<div class="row">						
					<div class="span9">								
						<ul class="thumbnails listing-products">
						<li class="span3">
								<div class="product-box">												
									<a href="bed.php"><img alt="" src=""></a><br><br>
									
									<a href="#" class="category">Double Ded</a>
									<p class="price">Rs.19000</p>
								</div>
							</li>
						<li class="span3">
								<div class="product-box">												
									<a href="bed.php"><img alt="" src=""></a><br><br>
									
									<a href="#" class="category">Double Ded</a>
									<p class="price">Rs.22000</p>
								</div>
							</li>
						
<li class="span3">
								<div class="product-box">												
									<a href="bed.php"><img alt="" src=""></a><br><br>
									
									<a href="#" class="category">Double Ded</a>
									<p class="price">Rs.25550</p>
								</div>
							</li>
							</li>
									
								
					</ul>								
						<hr>
						<div class="pagination pagination-small pagination-centered">
							<ul>
								<li><a href="#">Prev</a></li>
								<li class="active"><a href="#">1</a></li>
								<li><a href="#">2</a></li>
								<li><a href="#">3</a></li>
								
								<li><a href="#">Next</a></li>
							</ul>
						</div>
					</div>
					
				</div>
				
			</section>
			<?php include_once('footer.php');?>