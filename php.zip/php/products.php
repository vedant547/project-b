<?php include_once('header.php');?>
<section class="header_text sub">
				<h4><span>New products</span></h4>
			</section>
			<section class="main-content" style="margin-left: 145px! important;">
				
<div class="row">						
					<div class="span9">								
						<ul class="thumbnails listing-products">
							<li>
								<div class="product-box">
									<span class="sale_tag"></span>												
									<a href="Joshua.html"><img src="h1.jpg" height="900" width="200"></a><br/>
									<a href="Joshua.html" class="title">horrar books</a><br/>
									<a href="#" class="category">Joshua Hoffine</a>
									<a href="#" class="category"></a>
									<p class="price">Rs. 341</p>
								</div>
							</li>       
							<li>
								<div class="product-box">												
									<a href="How.html"><img src="C1.jpg" height="900" width="200"></a><br/>
									<a href="How.html" class="title">children books</a><br/>
									<a href="#" class="category">How Big Are Your Worries Little Bear?</a>
									<a href="#" class="category"></a>
									<p class="price">Rs. 28</p>
								</div>
							</li>
							<li>
								<div class="product-box">
									<span class="sale_tag"></span>												
									<a href="8.html"><img src="T1.jpg" height="900" width="200"></a><br/>
									<a href="8.html" class="title">technical books</a><br/>
									<a href="#" class="category">Technical Analysis Of Stock Trends</a>
									<a href="#" class="category"></a>
									<p class="price">Rs. 341</p>
								</div>
							</li>
							<li>
								<div class="product-box">                                        												
									<a href="ph.html"><img src="W1.jpg" height="900" width="200"></a><br/>
									<a href="ph.html" class="title">work books</a><br/>
									<a href="#" class="category">Phonics Workbook</a>
									<p class="price">Rs. 35</p>
								</div>
							</li>   
							<li>
								<div class="product-box">												
									<span class="sale_tag"></span>
									<a href="rrb.html"><img src="N1.jpg" height="900" width="200"></a><br/>
									<a href="rrb.html" class="title">non-technical books</a><br/>
									<a href="#" class="category">Railway Recruitment Board</a>
									<a href="#" class="category"></a>
									<p class="price">Rs. 49</p>
								</div>
							</li>    
							</ul>
						</div>
					</div>
					
				</div>
				
			</section>
			<?php include_once('footer.php');?>