<?php include_once('header.php');
include_once('unique.php');?>
<section class="header_text sub">
<section  class="homepage-slider" id="home-slider">

</section>
			<img class="pageBanner" src="themes/images/pageBanner.png" alt="New products" >
			<div class="control-group"  style="margin-left: 145px! important;">
					
				
</section>
<script>
function guestValidate(){
    

var fname = $("#firstname").val();
var upass=  $("#password").val();
if(uname.length==0){
        isError = 1;
        $("#span_name").show();
    }
     else {
        isError = 0;
        $("#span_name").hide();
    }
	if(uname.length==0){
        isError = 1;
        $("#span_password").show();
    }
     else {
        isError = 0;
        $("#span_password").hide();
    }
    if(isError==0){
        return true;
    } else {
        return false;
    }
}
function hidename(){
       $("#span_name").hide();

}
function hidepass(){
       $("#span_password").hide();
}
</script


					
							<div class="accordion-group">
								<div class="accordion-heading">
									<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo">Account &amp; Billing Details</a>
								</div>
								<div id="collapseTwo" class="accordion-body collapse">
									<div class="accordion-inner">
										<div class="row-fluid">
											<div class="span6">
												<h4>Your Personal Details</h4>
												<div class="control-group">
													<label class="control-label">First Name</label>
													<div class="controls">
														<input type="text" placeholder="" onblur="hidename()"idclass="input-xlarge">
														 <span class="error" style="display:none;" id="span_name"><br>* Please Enter Your Name.</span><br>
													</div>
												</div>
																  
												<div class="control-group">
													<label class="control-label">Email Address</label>
													<div class="controls">
														<input type="text" placeholder="" class="input-xlarge">
													</div>
												</div>
												
												<br>
												<h4>Shipping & Billing Information</h4>
												
												<input type="checkbox" value="option1"> Shipping & Billing Information is same
												<br>
												<br>
												<h4>Shipping Address</h4>
												<div class="control-group">
													<label class="control-label">Address</label>
													<div class="controls">
														<textarea rows="3" id="textarea" class="span7"></textarea>													</div>
												</div>
												<div class="control-group">
													<label class="control-label">Shipping Pincode</label>
													<div class="controls">
														<input type="number" placeholder="" class="input-xlarge">
										        </div>
												</div>
												
												
												
												
											</div>
											<div class="span6">
											   <div class="control-group"><br><br>
													<label class="control-label">Last Name</label>
													<div class="controls">
														<input type="text" placeholder="" class="input-xlarge">
													</div>
												</div>
												<div class="control-group">
													<label class="control-label">Contact No</label>
													<div class="controls">
														<input type="text" placeholder="" class="input-xlarge">
													</div>
												</div>					  
												<br><br><br><br><br>
												<h4>Billing Address</h4>
												<div class="control-group">
													<label class="control-label">Address</label>
													<div class="controls">
														<textarea rows="3" id="textarea" class="span7"></textarea>
													</div>
												</div>
												<div class="control-group">
													<label class="control-label">Billing Pincode</label>
													<div class="controls">
														<input type="number" placeholder="" class="input-xlarge">
										        </div>
												
												
											<div class="control-group">
												<label for="textarea" class="control-label">Comments</label>
												<div class="controls">
													<textarea rows="3" id="textarea" class="span12"></textarea>
												</div>
											</div>									
											<button class="btn btn-inverse pull-right">Confirm order</button>
										</div>
									</div>
								</div>				  
												
												
											</div>
										</div>
									</div>
								</div>
							</div>
							
						</div>				
					</div>
				</div>
			</section>
			<?php include_once('footer.php');?>