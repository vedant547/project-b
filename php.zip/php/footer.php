<section id="footer-bar">
				<div class="row" style="text-align: center!important;">
							<a href="./index.php">Home</a>  | 
							<a href="./about.php">About Us</a>  | 
							<a href="./contact.php">Contac Us</a>  | 
							<a href="./cart.php">Your Cart</a>  | 
							<a href="./register.php">Login</a>							
				</div>	
			</section>
		</div>
		<script src="themes/js/common.js"></script>
		<script src="themes/js/jquery.flexslider-min.js"></script>
		<script type="text/javascript">
			$(function() {
				$(document).ready(function() {
					$('.flexslider').flexslider({
						animation: "fade",
						slideshowSpeed: 4000,
						animationSpeed: 600,
						controlNav: false,
						directionNav: true,
						controlsContainer: ".flex-container" // the container that holds the flexslider
					});
				});
			});
		</script>
    </body>
</html>