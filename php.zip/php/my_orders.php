<?php include_once('header.php');
include_once('unique.php');?>
<section class="header_text sub">
<section  class="homepage-slider" id="home-slider">
			
</section>				
			<div class="control-group"  style="margin-left: 145px! important;">
			<h4><span>Order Details</span></h4>		
				
</section>
		
		
<table class="table table-striped">
								
								  <thead>
								  <tr>
									   
									   <th>Order Number</th>
									   <th>Order Status </th>
									   <th>Action</th>
							
								  </tr>
								  </thead> 
								  
								  

 <?php
		$query="select order_master_id,upper(order_status) as order_status from order_master where user_master_id=1";  
		$result=mysqli_query($con,$query);
		$row=mysqli_num_rows($result);
		
		if($row>0)
		{
				while($row=mysqli_fetch_assoc($result))
					   {
	?>
					<tr>
						<td><?php echo $row['order_master_id']; ?></td>
						
						<td><?php echo $row['order_status']; ?></td>
						<td><a href="my order.php?order_master_id=<?php echo $row['order_master_id']?>">View</a></td>
					</tr>
					<?php
				}
		}           
    ?>

									

</table>
		
			<?php include_once('footer.php');?>