<?php include_once('header.php');?>
<section class="header_text sub">
			<img class="pageBanner" src="themes/images/pageBanner.png" alt="New products" >
				<h4><span>Contact Us</span></h4>
			</section>
			<section class="main-content">				
				<div class="row">				
					<div class="span5">
						<div class= "contact">
							<h2>Vedant Nayak</h2>
							<p><strong>Phone:</strong>&nbsp;8200766052<br>
							<strong>Email:</strong>&nbsp;<a href="#">bookshop237@gmail.com</a>								
							</p>
							<br/>
							<h2>Vraj Parekh</h2>
							<p><strong>Phone:</strong>&nbsp;9586354038<br>
							<strong>Email:</strong>&nbsp;<a href="#">bookshop237@gmail.com</a>					
							</p>
							<br>
							<h2>Sahil Patel</h2>
							<p><strong>Phone:</strong>&nbsp;9512099882<br>
							<strong>Email:</strong>&nbsp;<a href="#">bookshop237@gmail.com</a>								
							</p>
						</div>
					</div>
					<div class="span7">
						<p>SED UT PERSPICIATIS UNDE OMNIS ISTE NATUS ERROR SIT VOLUPTATEM ACCUSANTIUM DOLOREMQUE LAUDANTIUM, TOTAM REM APERIAM, EAQUE IPSA QUAE AB ILLO INVENTORE VERITATIS ET QUASI ARCHITECTO BEATAE VITAE DICTA SUNT EXPLICABO.</p>
						<form method="post" action="#">
							<fieldset>
								<div class="clearfix">
									<label for="name"><span>Name:</span></label>
									<div class="input">
										<input tabindex="1" size="18" id="name" name="name" type="text" value="" class="input-xlarge" placeholder="Name">
									</div>
								</div>
								
								<div class="clearfix">
									<label for="email"><span>Email:</span></label>
									<div class="input">
										<input tabindex="2" size="25" id="email" name="email" type="text" value="" class="input-xlarge" placeholder="Email Address">
									</div>
								</div>
								
								<div class="clearfix">
									<label for="message"><span>Message:</span></label>
									<div class="input">
										<textarea tabindex="3" class="input-xlarge" id="message" name="body" rows="7" placeholder="Message"></textarea>
									</div>
								</div>
								
								<div class="actions">
									<button tabindex="3" type="submit" class="btn btn-inverse">Send message</button>
								</div>
							</fieldset>
						</form>
					</div>				
				</div>
			</section>	
			<?php include_once('footer.php');?>