<?php include_once('header.php');?>
<section class="header_text sub">
<section  class="homepage-slider" id="home-slider">
							

</section>
			
			<div class="control-group"  >
					



Unique furniture mart offers a unique selection of stylish,contemporary, and chic furniture online.
				Our online furniture range includes Sofas, Beds, Chairs, Daining-table, Wardrobes, and lots more.
</div>
</section>
			<?php include_once('footer.php');?>