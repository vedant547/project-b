<?php
include_once('connection.php');
if (isset($_POST['add_staff']))
{
	$staff_name=$_POST['sname'];
	$staff_add=$_POST['address'];
	$contact_no=$_POST['contact'];
	$query="insert into staff (staff_name,staff_add,contact_no) values ('$staff_name','$staff_add',$contact_no)";
	if(mysqli_query($con,$query))
	{
		echo("<script>alert('Success');</script>");
	}
	else
	{
		echo("<script>alert('Error');</script>");
	}


}
if(isset($_GET['staff_id'])){
    $q = "Delete From staff where staff_id=".$_GET['staff_id'];
    mysqli_query($con,$q);
    header("Location:staff.php");
}
?>

<form method="POST">
Enter Name:<input type="text" name= "sname"> <br>

Enter Address:<input type="text" name= "address"> <br>
Enter Contact:<input type="text" name= "contact"><br>

<select id="s1" name="s1">
  <option value="0">select product</option>
   <option value="1">111</option>
   <option value="2">222</option>
   <option value="3">333</option>
   <option value="4">444</option>
   <option value="5">555</option>
  
  
  <?php 
  $query = "Select * from product";
  $result = mysqli_query($con,$query);
  $rows = mysqli_num_rows($result);
  if($rows>0)
 {
	 $result_set=mysqli_query($con,$q);
    while($row = mysqli_fetch_assoc($result))
    {
         ?>
<option value="<?php echo $row['product_id'];?>"><?php echo $row['product_name'];?>
         <?php
	}
 }
?> 
</select>  
<br>
<input type="submit" Value="Submit" name="add_staff">
</form>

<table border="1"	>
<tr>
<td> ID </td>
<td> Name  </td>
<td> Address </td>
<td> Contact </td>
<td> Action </td>
</tr>

<?php 
  $query = "Select * from staff_detail";
  $result = mysqli_query($con,$query);
  $rows = mysqli_num_rows($result);
  if($rows>0)
 {
    while($row = mysqli_fetch_assoc($result))
    {
         ?>
       
<tr>
<td> <?php echo $row['staff_id'] ?> </td>
<td> <?php echo $row['staff_name'] ?> </td>
<td> <?php echo $row['staff_add'] ?> </td>
<td> <?php echo $row['contact_no'] ?> </td>
<td> <a>Edit</a> &nbsp; &nbsp; &nbsp; <a href="staff.php?staff_id=<?php echo $row['staff_id'] ?>">Delete</a> </td>
</tr>

      <?php
     }
 }
?>
</table>











