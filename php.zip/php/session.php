<?php
session_start();
	 if(!isset($_SESSION['user_master_id']) && !isset($SESSION['password']))
	 {
	     header("location:login.php");
	  }	 
?>