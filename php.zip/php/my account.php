<?php include_once('header.php');?>

<section  class="homepage-slider" id="home-slider">	
	
				
			
			<section class="main-content" style="margin-left: 145px! important;">				
				<div class="row">
					<div class="span9">
			
					<nav id="menu" class="pull-right">
						<ul>
										
							
							    <ul>									
									<li><a href="./my order.php">My order</a></li>
									<li><a href="./profile.php">Profile</a></li>
									<li><a href="./password.php">Change password</a></li>
									

								</ul>
							</li>
						</ul>
					</nav>
				</div>
			</section>
			</section>
			<?php include_once('footer.php');?>
