<?php include_once('header.php');?>
<section class="header_text sub">
			<div class="control-group"  style="margin-left: 145px! important;">
					
				
</section>
			<section class="main-content" style="margin-left: 145px! important;">
				
				<div class="row">						
					<div class="span9">								
						<ul class="thumbnails listing-products">
							<li class="span3">
								<div class="product-box">
									<span class="sale_tag"></span>												
									<a href="ph.html"><img alt="" src="W1.jpg"></a><br/>
									<a href="ph.html" class="title">work books</a><br/>
									<a href="#" class="category">phonics</a>
									<p class="price">Rs. 341</p>
								</div>
							</li>       
							<li class="span3">
								<div class="product-box">												
									<a href="ge.html"><img alt="" src="W2.jpg"></a><br/>
									<a href="ge.html" class="title">work books</a><br/>
									<a href="#" class="category">genius kids</a>
									<p class="price">Rs. 250</p>
								</div>
							</li>
							<li class="span3">
								<div class="product-box">
									<span class="sale_tag"></span>												
									<a href="oly.html"><img alt="" src="W3.jpg"></a><br/>
									<a href="oly.html" class="title">work books</a><br/>
									<a href="#" class="category">olympiad</a>
									<p class="price">Rs. 341</p>
								</div>
							</li>
						</ul>								
						<hr>
						<div class="pagination pagination-small pagination-centered">
							<ul>
								<li><a href="#">Prev</a></li>
								<li class="active"><a href="#">1</a></li>
								<li><a href="#">2</a></li>
								<li><a href="#">3</a></li>
								<li><a href="#">4</a></li>
								<li><a href="#">Next</a></li>
							</ul>
						</div>
					
				</div>
						<div class="pagination pagination-small pagination-centered">
							<ul>
								<li><a href="#">Prev</a></li>
								<li><a href="sofa.php">1</a></li>
								<li><a href="sofa2.php">2</a></li>
								
								
								<li><a href="#">Next</a></li>
							</ul>
						</div>
					</div>
					
				</div>
				
			</section>
			<?php include_once('footer.php');?>