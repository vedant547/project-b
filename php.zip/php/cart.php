<?php include_once('header.php');?>
<section class="header_text sub">
				<h4><span>Shopping Cart</span></h4>
			</section>
			<section class="main-content" style="margin-left: 145px! important;">				
				<div class="row">
					<div class="span9">					
						<h4 class="title"><span class="text"><strong>Your</strong> Cart</span></h4>
						<table class="table table-striped">
							<thead>
								<tr>
									<th>Select</th>
									<th>Image</th>
									<th>Product Name</th>
									<th>Quantity</th>
									<th>Unit Price</th>
									<th>Total</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td><input type="checkbox" value="option1"></td>
									<td><a href="joshua.html"><img alt="" src="H1.jpg"></a></td>
									<td>Horrar Book</td>
									<td><input type="text" placeholder="1" class="input-mini"></td>
									<td>Rs. 350.00</td>
									<td>Rs. 350.00</td>
								</tr>			  
								<tr>
									<td><input type="checkbox" value="option1"></td>
									<td><a href="How.html"><img alt="" src="C1.jpg"></a></td>
									<td>Children Book</td>
									<td><input type="text" placeholder="1" class="input-mini"></td>
									<td>Rs. 150.00</td>
									<td>Rs. 450.00</td>
								</tr>
								<tr>
									<td><input type="checkbox" value="option1"></td>
									<td><a href="8.html"><img alt="" src="T1.jpg"></a></td>
									<td>Technical Book</td>
									<td><input type="text" placeholder="1" class="input-mini"></td>
									<td>Rs. 210.00</td>
									<td>Rs. 123.00</td>
								</tr>
								
								<tr>
									<td>&nbsp;</td>
									<td>&nbsp;</td>
									<td>&nbsp;</td>
									<td>&nbsp;</td>
									<td>&nbsp;</td>
									<td><strong>Rs. 600.00</strong></td>
								</tr>		  
							</tbody>
						</table>
						<hr/>
						<p class="buttons center">				
							<button class="btn" type="button">Delete</button>
							<button class="btn" type="button">Rent</button>
							<button class="btn" type="button">Payment</button>
						</p>	
						<p class="cart-total right">
							<strong>Sub-Total</strong>:	Rs. 100.00<br>
							<strong>Eco Tax (-2.00)</strong>: Rs. 2.00<br>
							<strong>VAT (17.5%)</strong>: Rs. 17.50<br>
							<strong>Total</strong>: Rs. 119.50<br>
						</p>				
					</div>
					
				</div>
			</section>
			<?php include_once('footer.php');?>