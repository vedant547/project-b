<?php include_once('header.php');
include_once('unique.php');?>
<section class="header_text sub">
<section  class="homepage-slider" id="home-slider">
				
</section>				
			<div class="control-group"  style="margin-left: 145px! important;">
			<h4><span>Order Details</span></h4>		
				
</section>
		
		
<table class="table table-striped">
								
								  <thead>
								  <tr>
									   
									   <th>Image</th>
									   <th>Sub Product Name </th>
									   <th>Quantity</th>
									   <th>Price</th>
							
								  </tr>
								  </thead> 
								  
								  

 <?php
		$id=$_GET['order_master_id'];
		$query="select sp.image,sp.sub_product_name,sp.sub_product_description,od.price,od.quantity from sub_product_master sp,order_details od where sp.sub_product_id=od.sub_product_id and order_master_id=$id";  
		$result=mysqli_query($con,$query);
		$row=mysqli_num_rows($result);
		
		if($row>0)
		{
				while($row=mysqli_fetch_assoc($result))
					   {
	?>
					<tr>
						<td><img src="images/sofas/<?php echo $row['image']?>" /></td>
						
						<td><?php echo $row['sub_product_name']; ?> <br> 
						<?php echo $row['sub_product_description']; ?>
						</td>
						<td><?php echo $row['quantity']; ?></td>
						<td><?php echo $row['price']; ?></td>
					</tr>
					<?php
				}
		}           
    ?>

									

</table>
		
			<?php include_once('footer.php');?>