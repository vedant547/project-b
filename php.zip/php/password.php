<?php include_once('header.php');
include_once('unique.php');?>

<section class="header_text sub">
<section  class="homepage-slider" id="home-slider">		

</section>
			<div class="control-group"  style="margin-left: 145px! important;">
					
				
</section>
	
			
						<?php
		if(isset($_POST['add_unique']))
		{
			
			$old_password=$_POST['old_password'];
			$new_password=$_POST['new_password'];
			$confirm_password=$_POST['confirm_password'];
			if($new_password==$confirm_password)
			{
			$query="UPDATE user_master set password='$new_password'
			        where user_master_name='nisha' and user_role_id=2";
			
			if(mysqli_query($con,$query))
			{
				echo("<script>alert('Success..!!');</script>");
			
			}	
			else
			{
				echo("<script>alert('Error..!!');</script>");
			}
			}
			else
			{
				echo("<script>alert('pass and cin not sem..!!');</script>");
			}
			
		 	
		}
			

?>


											<h4 class="title"><span class="text"><strong>Change </strong> Password</span></h4>
 <form role="form" method="post">
						<div class="box-body">
						    
							<div class="col-md-8">
								<div class="form-group">
									<label for="exampleInputEmail1"> Old Password</label>
								    <input type="password" class="form-control" placeholder="Enter Password"name="old_password"  id="old_password" required=''>
								</div>
							</div>
							
							<div class="col-md-8">
								<div class="form-group">
									<label for="exampleInputEmail1">New Password</label>
								    <input type="password" class="form-control"placeholder="Enter Your New Password" name="new_password"  id="password" required='' >
								</div>
							</div>
							<br>
							<div class="col-md-8">
								<div class="form-group">
									<label for="exampleInputEmail1">Confirm Password</label>
								    <input type="password" class="form-control"placeholder="Enter Your New Password" name="confirm_password"  id="password" required=''>
								</div>
							</div>
							<br>
							<div class="col-md-8">
								<div class="box-footer">
						        <input type="submit" name="add_unique" value="Change Password" class="btn btn-primary">
								</div>
							</div>

						</div>
					</form>
					

 <?php include_once('footer.php');?>