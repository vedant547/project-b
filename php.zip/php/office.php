<?php include_once('header.php');?>
<section class="header_text sub">
			<div class="control-group"  style="margin-left: 145px! important;">
					
				
</section>
                <center>
				<h4><span>Office Chair</span></h4>
				</center>
			</section><br>
			<section class="main-content" style="margin-left: 145px! important;">
				
				<div class="row">						
					<div class="span9">								
						<ul class="thumbnails listing-products">
						<li class="span3">
								<div class="product-box">												
									<a href="product_detail.html"><img alt="" src=""></a><br><br>
									
									
									<p class="price">Rs.1200</p>
								</div>
							</li>
							<li class="span3">
								<div class="product-box">												
									<a href="product_detail.html"><img alt="" src=""></a><br><br>
									
									
									<p class="price">Rs.1100</p>
								</div>
							</li>
							<li class="span3">
								<div class="product-box">												
									<a href="product_detail.html"><img alt="" src=""></a><br><br>
									
									
									<p class="price">Rs.1500</p>
								</div>
							</li>
							<li class="span3">
								<div class="product-box">												
									<a href="product_detail.html"><img alt="" src=""></a><br><br>
									
									
									<p class="price">Rs.1399</p>
								</div>
							</li>
							<li class="span3">
								<div class="product-box">												
									<a href="product_detail.html"><img alt="" src=""></a><br><br>
									
									
									<p class="price">Rs.1200<p>
								</div>
							</li>

							<li class="span3">
								<div class="product-box">												
									<a href="product_detail.html"><img alt="" src=""></a><br><br>
									
									
									<p class="price">Rs.1550</p>
								</div>
							</li>
							



							

													</ul>								
						<hr>
						<div class="pagination pagination-small pagination-centered">
							<ul>
								<li><a href="#">Prev</a></li>
								<li><a href="chair.php">1</a></li>
								<li><a href="home.php">2</a></li>
								<li><a href="office.php">3</a></li>
								<li><a href="banches.php">4</a></li>
								<li><a href="#">Next</a></li>
							</ul>
						</div>
					</div>
					
				</div>
				
			</section>
			<?php include_once('footer.php');?>