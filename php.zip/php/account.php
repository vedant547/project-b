<?php include_once('header.php');
include_once('unique.php');?>
<section class="header_text sub">
<section  class="homepage-slider" id="home-slider">
						

</section>
			
			<div class="control-group"  style="margin-left: 145px! important;">
					
				
</section>
<script>
function changeValueOfCheckBox(){
	if(document.getElementById("checkId").checked){
	$("#billShipAdd").val(1);
	}else{
	$("#billShipAdd").val(0);		
	}
}
</script>
<script>
function billingValidate(){
    

var fname = $("#firstname").val();
var femail=  $("#emailid").val();
var fadd=  $("#shipadd").val();
var fship=  $("#shippingpincode").val();
var flast=  $("#lastname").val();
var fcon=  $("#contactno").val();
var fbill=  $("#address").val();
var fpin=  $("#billingpincode").val();
var fcomm=  $("#comment").val();

if(fname.length==0){
        isError = 1;
        $("#span_name").show();
    }
     else {
        isError = 0;
        $("#span_name").hide();
    }
	if(femail.length==0){
        isError = 1;
        $("#span_email").show();
    }
     else {
        isError = 0;
        $("#span_email").hide();
    }
	if(fadd.length==0){
        isError = 1;
        $("#span_add").show();
    }
     else {
        isError = 0;
        $("#span_add").hide();
    }
	if(fship.length==0){
        isError = 1;
        $("#span_ship").show();
    }
     else {
        isError = 0;
        $("#span_ship").hide();
    }
	if(flast.length==0){
        isError = 1;
        $("#span_last").show();
    }
     else {
        isError = 0;
        $("#span_last").hide();
    }
	if(fcon.length==0){
        isError = 1;
        $("#span_con").show();
    }
     else {
        isError = 0;
        $("#span_con").hide();
    }
	if(fbill.length==0){
        isError = 1;
        $("#span_bill").show();
    }
     else {
        isError = 0;
        $("#span_bill").hide();
    }
	if(fpin.length==0){
        isError = 1;
        $("#span_pin").show();
    }
     else {
        isError = 0;
        $("#span_pin").hide();
    }
	if(fcomm.length==0){
        isError = 1;
        $("#span_comm").show();
    }
     else {
        isError = 0;
        $("#span_comm").hide();
    }
	
	
    if(isError==0){
        return true;
    } else {
        return false;
    }
}
function hidename(){
       $("#span_name").hide();

}
function hideemail(){
       $("#span_email").hide();
}
function hideadd(){
       $("#span_add").hide();

}
function hideship(){
       $("#span_ship").hide();

}
function hidelast(){
       $("#span_last").hide();

}
function hidecon(){
       $("#span_con").hide();

}
function hidebill(){
       $("#span_bill").hide();

}
function hidepin(){
       $("#span_pin").hide();

}
function hidecomm(){
       $("#span_comm").hide();

}

</script>


				

<?php
if (isset($_POST['add_unique']))
{
    $user_master_id=2;
	$first_name=$_POST['first_name'];
	$last_name=$_POST['last_name'];
	$contact_no=$_POST['contact_no'];
    $email_id=$_POST['email_id'];
	$shipping_address=$_POST['shipping_address'];
	$shipping_pincode=$_POST['shipping_pincode'];
	$billing_address=$_POST['billing_address'];
	$billing_pincode=$_POST['billing_pincode'];
    $comment=$_POST['comment'];
	$query ="insert into order_master(user_master_id,first_name,last_name,contact_no,email_id,shipping_address,shipping_pincode,billing_address,billing_pincode,comment,is_active,order_date,updated_date) values (2,'$first_name','$last_name',$contact_no,'$email_id','$shipping_address',$shipping_pincode,'$billing_address',$billing_pincode,'$comment',1,now(),now())";
	
			if(mysqli_query($con,$query))
			{
			  $orderid=mysqli_insert_id($con);
			  $query="select sp.sub_product_id,cd.quantity,sp.price from sub_product_master sp,cart_details cd where cd.sub_product_id=sp.sub_product_id ";
			  $result=mysqli_query($con,$query);
		      $row=mysqli_num_rows($result);
		
		if($row>0)
		{
				while($row=mysqli_fetch_assoc($result))
					   {
					   $sub_product_id=$row['sub_product_id'];
					   $quantity=$row['quantity'];
					   $price=$row['price'];
					   $query="insert into order_details(order_master_id,sub_product_id,quantity,price,is_active,created_date,updated_date)values($orderid,$sub_product_id,$quantity,$price,1,now(),now())";
					   mysqli_query($con,$query);
					   }
		}
		    		   $update_cart="update cart_details set is_active=0 where user_master_id=1";
					   mysqli_query($con,$update_cart);
					   
				       echo("<script>alert('Success..!!');</script>");
	                   }	
			           else
			          {
				       echo("<script>alert('Error..!!');</script>");
			          }	
		}

		?>
              	<div class="accordion-group">
<style>
.error{color:red;font-size: 15px;}
</style>

							<form method="POST">
								<div class="accordion-heading">
									<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo">Account &amp; Billing Details</a>
								</div>
								<div id="collapseTwo" class="accordion-body collapse">
									<div class="accordion-inner">
										<div class="row-fluid">
											<div class="span6">
												<h4>Your Personal Details</h4>
												<div class="control-group">
													<label class="control-label">First Name</label>
													<div class="controls">
														<input type="text" placeholder="" id="firstname"onblur="hidename()" name="first_name" class="input-xlarge">
                                                        <span class="error" style="display:none;" id="span_name"><br>* Please Enter Your Name.</span><br>
													
	</div>
												</div>
																  
												<div class="control-group">
													<label class="control-label">Email Address</label>
													<div class="controls">
														<input type="email" placeholder="" id="emailid"onblur="hideemail()" name="email_id" class="input-xlarge">
                                                        <span class="error" style="display:none;" id="span_email"><br>* Please Enter Your Email Id.</span><br>												
												</div>
												</div>
												
												<br>
												<h4>Shipping & Billing Information</h4>
												
												<input type="checkbox" value="option1"> Shipping & Billing Information is same
												<br>
												<br>
												<h4>Shipping Address</h4>
												<div class="control-group">
													<label class="control-label">Address</label>
													<div class="controls">
														<textarea rows="3" id="shipadd"onblur="hideadd()" name="shipping_address"class="span7"></textarea>
														 <span class="error" style="display:none;" id="span_add"><br>* Please Enter Your Shipping Address.</span><br>
														</div>
												</div>
												<div class="control-group">
													<label class="control-label">Shipping Pincode</label>
													<div class="controls">
														<input type="number" placeholder=""name="shipping_pincode" id="shippingpincode"onblur="hideship()"class="input-xlarge">
														 <span class="error" style="display:none;" id="span_ship"><br>* Please Enter Your Shipping Pincode.</span><br>
										        </div>
												</div>
												
												
												
												
											</div>
											<div class="span6">
											   <div class="control-group"><br><br>
													<label class="control-label">Last Name</label>
													<div class="controls">
														<input type="text" placeholder="" id="lastname"name="last_name" onblur="hidelast()"class="input-xlarge">
														 <span class="error" style="display:none;" id="span_last"><br>* Please Enter Your Last Name.</span><br>
													</div>
												</div>
												<div class="control-group">
													<label class="control-label">Contact No</label>
													<div class="controls">
														<input type="text" id="contactno" placeholder="" name="contact_no"onblur="hidecon()" class="input-xlarge">
														 <span class="error" style="display:none;" id="span_con"><br>* Please Enter Your Contact No.</span><br>
													</div>
												</div>					  
												<br><br><br><br><br>
												<h4>Billing Address</h4>
												<div class="control-group">
													<label class="control-label">Address</label>
													<div class="controls">
														<textarea rows="3" id="address" name="billing_address"onblur="hidebill()" class="span7"></textarea>
														 <span class="error" style="display:none;" id="span_bill"><br>* Please Enter Your Billing Address.</span><br>
													</div>
												</div>
												<div class="control-group">
													<label class="control-label">Billing Pincode</label>
													<div class="controls">
														<input type="number" placeholder="" id="billingpincode"onblur="hidepin()"name="billing_pincode"class="input-xlarge">
														 <span class="error" style="display:none;" id="span_pin"><br>* Please Enter Your Billing Pincode.</span><br>
										        </div>
												
												
											<div class="control-group">
												<label for="textarea" class="control-label">Comments</label>
												<div class="controls">
													<textarea rows="3" id="comment" name="comment" onblur="hidecomm()"class="span12"></textarea>
													 <span class="error" style="display:none;" id="span_comm"><br>* Please Enter Comment.</span><br>
												</div>
											</div>									
											<div class="box-footer">
			                       <input type="submit"  class="btn btn-inverse" name="add_unique" onclick="return billingValidate();"value="Confirm order" id="Confirm Order">
									
								</div>
										</div>
									</div>
								</div>				  
												
												
											</div>
										</div>
									</div>
								</div>
							</div>
							</form>
						</div>				
					</div>
				</div>
			</section>
			<?php include_once('footer.php');?>