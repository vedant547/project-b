<?php include_once('header.php');
include_once('unique.php')?>
										
	<section  class="homepage-slider" id="home-slider">			
			<section class="header_text">

Unique furniture mart offers a unique selection of stylish,contemporary, and chic furniture online.
				Our online furniture range includes Sofas, Beds, Chairs, Daining-table, Wardrobes, and lots more.
			</section>	
    </section>

	<section class="main-content">
	<div class="row">
		<div class="span12">													
			<div class="row">
				<div class="span12">
					<h4 class="title" style="margin-left: 500px! important;">
						<span class="pull-left"><span class="text">OUR Products</span></span>
						<span class="pull-right">
							<a class="left button" href="#myCarousel" data-slide="prev"></a><a class="right button" href="#myCarousel" data-slide="next"></a>
						</span>
					</h4>
								<br>		
	
					<div id="myCarousel" class="myCarousel carousel slide">
						<div class="carousel-inner">
							<div class="active item">
				    <?php 
					$query = "Select * from sub_product_master where is_active=1";
					$result = mysqli_query($con,$query);
					$rows = mysqli_num_rows($result);
					$temp=0;
					if($rows>0)
					{
						while($row = mysqli_fetch_assoc($result))
						{
						if($temp==0){
						?>
							<ul class="thumbnails" >	
						<?php
						}
						?>
							<li class="span3">
											<div class="product-box">
												<span class="sale_tag"></span>
												<p><a href="product_detail.php?subProductId=<?php echo $row['sub_product_id']?>"><img src="images/sofas/<?php echo $row['image']?>" /></a></p>
												<a href="product_detail.php?subProductId=<?php echo $row['sub_product_id']?>" class="title"><?php echo $row['sub_product_name']?></a><br/>
								
												<p class="price">Rs. <?php echo $row['price']?></p>
											</div>
							</li>							
						<?php
						$temp+=1;
						if($temp==4){
						$temp = 0;
						?>
						</ul>
						<?php
						}
						}
					}	
       				?>															
				    </ul>
					</div>
													</div>							
					</div>
				</div>						
			</div>
					
								
			<br/>
			
			<div class="row feature_box">						
				<div class="span4">
					<div class="service">
						<div class="responsive">	
							<img src="themes/images/feature_img_2.png" alt="" />
							<h4>MODERN <strong>DESIGN</strong></h4>
							<p>Articles of wooden furniture marquetry and inlaid wood; caskets and cases for jewellery or cytlrty,and.</p>									
						</div>
					</div>
				</div>
				<div class="span4">	
					<div class="service">
						<div class="customize">			
							<img src="themes/images/feature_img_1.png" alt="" />
							<h4>FREE <strong>SHIPPING</strong></h4>
							<p>We are provide free shipping delivery in all city area of gujrat.</p>
						</div>
					</div>
				</div>
				<div class="span4">
					<div class="service">
						<div class="support">	
							<img src="themes/images/feature_img_3.png" alt="" />
							<h4>24/7 LIVE <strong>SUPPORT</strong></h4>
							<p>Get in touch 24/7 there are huge profits of furniture we will truly like </p>
						</div>
					</div>
				</div>	
			</div>		
		</div>				
	</div>
</section>
<?php include_once('footer.php');?>




